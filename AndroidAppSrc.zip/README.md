# DentistAppointmentSchedulerAndroid
Native Android application that uses a Web Service to make a Dentist Appointment &amp; view the scheduled appointments
